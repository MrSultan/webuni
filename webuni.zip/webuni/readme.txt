Admin Panel is in /dashboard
Only "Categories" was done and done partially, but hopefully amounts to something