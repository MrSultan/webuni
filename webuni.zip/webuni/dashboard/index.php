<html>
    <head>
    </head>
    <body>
        <ul>
            <li><a href="blog.php">Blog</a></li>
            <li><a href="categories.php">Categories</a></li>
            <li><a href="courses.php">Courses</a></li>
            <li><a href="users.php">Users</a></li>
        </ul>
    </body>
</html>