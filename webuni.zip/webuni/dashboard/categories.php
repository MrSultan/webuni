<?php
    if (isset($_GET['action']) && $_GET['action'] == "save") {
        $dbhost = 'localhost';
        $dbuser = 'root';
        $dbpass = '';
        $dbname = 'webuni';
        
        $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

        if (!$conn) {
            die('Could not connect: ' . mysqli_error());
        }
        
        $id = $_GET['id'];
        $category = $_GET['category'];
        $is_featured = (isset($_GET['is_featured']) && $_GET['is_featured'] === "on" ? 1 : 0);

        echo 'Connected successfully<br>';
        $sql = "UPDATE Categories SET Name='$category', Is_Featured=$is_featured WHERE Id=$id";

        if (mysqli_query($conn, $sql)) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
        
        mysqli_close($conn);
        
        header('Location: categories.php');
    }
?>

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <table>
            <tr>
                <th>Category</th>
                <th>Featured</th>
                <th>∞∞∞∞</th>
            </tr>
            <?php
                try {
                    $mysqli = new mysqli("localhost", "root", "", "webuni");
            
                    /* проверка подключения */
                    if ($mysqli->connect_errno) {
                        throw new Exception("Не удалось подключиться: %s\n" . $mysqli->connect_error);
                    }
                    
                    $query = "SELECT Id, Name, Is_Featured FROM Categories ORDER by Id";
                    $result = $mysqli->query($query);
                    
                    while ($row = $result->fetch_array(MYSQLI_NUM)) {
                        $id = $row[0];
                        $category_name = $row[1];
                        $is_featured = $row[2];
            ?><tr>
                <form action="categories.php" method="get">
                <input type="number" name="id" value="<?php echo $id ?>" hidden>
                <td><input placeholder="" type="text" name="category" value="<?php echo $category_name ?>" placeholder="Category name"></td>
                <td><input type=checkbox name="is_featured"<?php if ($is_featured) echo " checked" ?>></input></td>
                <td><input type="submit" name="action" value="save"></td>
                </form>
            </tr>
            <?php
                    }
                    
                    /* очищаем результаты выборки */
                    $result->free();

                    /* закрываем подключение */
                    $mysqli->close();
                } catch (Exception $e) {
                    echo 'Выброшено исключение: ',  $e->getMessage(), "\n";
                }
                
            ?>
            <tr>
                <form action="categories.php" method="get">
                <td><input type="text" name="category" placeholder="Category name"></td>
                <td><input type=checkbox name="is_featured"></td>
                <td><input type="submit" name="action" value="add"></td>
                </form>
            </tr>
        </table>
        <?php
            // fetch data from categories table
        ?>
    </body>
</html>